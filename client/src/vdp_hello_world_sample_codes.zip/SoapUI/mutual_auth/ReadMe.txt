Please refer to the below page 
https://developer.visa.com/pages/working-with-visa-apis/two-way-ssl#configuring_soap_ui_twoway_ssl_preferences
