Please refer to the below page 
https://developer.visa.com/pages/working-with-visa-apis/x-pay-token#testing_xpaytoken_connectivity_using_soapui
