<?php
/**
 * (c) Copyright 2018 - 2020 Visa. All Rights Reserved.**
 *
 * NOTICE: The software and accompanying information and documentation (together, the “Software”) remain the property of and are proprietary to Visa and its suppliers and affiliates. The Software remains protected by intellectual property rights and may be covered by U.S. and foreign patents or patent applications. The Software is licensed and not sold.*
 *
 *  By accessing the Software you are agreeing to Visa's terms of use (developer.visa.com/terms) and privacy policy (developer.visa.com/privacy).In addition, all permissible uses of the Software must be in support of Visa products, programs and services provided through the Visa Developer Program (VDP) platform only (developer.visa.com). **THE SOFTWARE AND ANY ASSOCIATED INFORMATION OR DOCUMENTATION IS PROVIDED ON AN “AS IS,” “AS AVAILABLE,” “WITH ALL FAULTS” BASIS WITHOUT WARRANTY OR  CONDITION OF ANY KIND. YOUR USE IS AT YOUR OWN RISK.** All brand names are the property of their respective owners, used for identification purposes only, and do not imply product endorsement or affiliation with Visa. Any links to third party sites are for your information only and equally  do not constitute a Visa endorsement. Visa has no insight into and control over third party content and code and disclaims all liability for any such components, including continued availability and functionality. Benefits depend on implementation details and business factors and coding steps shown are exemplary only and do not reflect all necessary elements for the described capabilities. Capabilities and features are subject to Visa’s terms and conditions and may require development,implementation and resources by you based on your business and operational details. Please refer to the specific API documentation for details on the requirements, eligibility and geographic availability.*
 *
 * This Software includes programs, concepts and details under continuing development by Visa. Any Visa features,functionality, implementation, branding, and schedules may be amended, updated or canceled at Visa’s discretion.The timing of widespread availability of programs and functionality is also subject to a number of factors outside Visa’s control,including but not limited to deployment of necessary infrastructure by issuers, acquirers, merchants and mobile device manufacturers.*
 *
 */

echo '<br/>START Sample Code for Two-Way (Mutual) SSL<br/>';
$url = 'https://sandbox.api.visa.com/vdp/helloworld';

// THIS IS EXAMPLE ONLY how will apiKey and sharedSecret look like
// apiKey = "1WM2TT4IHPXC8DQ5I3CH21n1rEBGK-Eyv_oLdzE2VZpDqRn_U";
// sharedSecret = "19JRVdej9";
$apiKey = '<YOUR API KEY>';
$sharedSecret = '<YOUR SHARED SECRET>';

$resource_path = 'helloworld';
$query_string = 'apiKey=' . $apiKey;
$body = '';

$curl = curl_init();
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

curl_setopt($curl, CURLOPT_PORT, 443);
curl_setopt($curl, CURLOPT_VERBOSE, 1);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 2);
curl_setopt($curl, CURLOPT_SSLVERSION, 1);

$time = time();
$pre_hash_string = $time . $resource_path . $query_string . $body;
$hashtoken = "xv2:" . $time . ":" . hash_hmac('sha256', $pre_hash_string, $sharedSecret);

$authHeader = "x-pay-token: " . $hashtoken;
$header = (array("Accept: application/json", "Content-Type: application/json", $authHeader));
curl_setopt($curl, CURLOPT_HTTPHEADER, $header);

$url = $url . '?' . $query_string;

curl_setopt($curl, CURLOPT_URL, $url);

// Make the request
$response = curl_exec($curl);

$response_info = curl_getinfo($curl);

if ($response_info['http_code'] === 0) {
    $curl_error_message = curl_error($curl);

    // curl_exec can sometimes fail but still return a blank message from curl_error().
    if (!empty($curl_error_message)) {
        $error_message = "API call to $url failed: $curl_error_message";
    } else {
        $error_message = "API call to $url failed, but for an unknown reason. " .
            "This could happen if you are disconnected from the network.";
    }
    echo $error_message;
} elseif ($response_info['http_code'] >= 200 && $response_info['http_code'] <= 299) {
    echo "Your call returned with a success code - " . $response_info['http_code'] . "<br/>";
    echo "<br/>Json Response: $response";
} else {
    echo "<br/>[HTTP Status: " . $response_info['http_code'] . "]\n\n[" . $response . "]<br/>";
    echo "<br/>Error connecting to the API ($url)<br/>";
}
echo '<br/>END Sample Code for Two-Way (Mutual) SSL<br/>';
