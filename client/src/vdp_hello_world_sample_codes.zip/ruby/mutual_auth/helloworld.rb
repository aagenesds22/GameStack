# *(c) Copyright 2018 - 2020 Visa. All Rights Reserved.**
#
# *NOTICE: The software and accompanying information and documentation (together, the “Software”) remain the property of and are proprietary to Visa and its suppliers and affiliates. The Software remains protected by intellectual property rights and may be covered by U.S. and foreign patents or patent applications. The Software is licensed and not sold.*
#
# * By accessing the Software you are agreeing to Visa's terms of use (developer.visa.com/terms) and privacy policy (developer.visa.com/privacy).In addition, all permissible uses of the Software must be in support of Visa products, programs and services provided through the Visa Developer Program (VDP) platform only (developer.visa.com). **THE SOFTWARE AND ANY ASSOCIATED INFORMATION OR DOCUMENTATION IS PROVIDED ON AN “AS IS,” “AS AVAILABLE,” “WITH ALL FAULTS” BASIS WITHOUT WARRANTY OR  CONDITION OF ANY KIND. YOUR USE IS AT YOUR OWN RISK.** All brand names are the property of their respective owners, used for identification purposes only, and do not imply product endorsement or affiliation with Visa. Any links to third party sites are for your information only and equally  do not constitute a Visa endorsement. Visa has no insight into and control over third party content and code and disclaims all liability for any such components, including continued availability and functionality. Benefits depend on implementation details and business factors and coding steps shown are exemplary only and do not reflect all necessary elements for the described capabilities. Capabilities and features are subject to Visa’s terms and conditions and may require development,implementation and resources by you based on your business and operational details. Please refer to the specific API documentation for details on the requirements, eligibility and geographic availability.*
#
# *This Software includes programs, concepts and details under continuing development by Visa. Any Visa features,functionality, implementation, branding, and schedules may be amended, updated or canceled at Visa’s discretion.The timing of widespread availability of programs and functionality is also subject to a number of factors outside Visa’s control,including but not limited to deployment of necessary infrastructure by issuers, acquirers, merchants and mobile device manufacturers.*
#
require 'rest-client'
require 'yaml'
require 'sysrandom'
require 'json'

@visa_url = 'https://sandbox.api.visa.com/'

# THIS IS EXAMPLE ONLY how will user_id and password look like
# user_id = '1WM2TT4IHPXC8DQ5I3CH21n1rEBGK-Eyv_oLdzE2VZpDqRn_U'
# password = '19JRVdej9'
@user_id = '<YOUR USER ID>'
@password = '<YOUR PASSWORD>'

# THIS IS EXAMPLE ONLY how will cert and key look like
# key_path = 'key_83d11ea6-a22d-4e52-b310-e0558816727d.pem'
# cert_path = 'cert.pem'

@key_path = '<YOUR PRIVATE KEY PATH>'
@cert_path = '<YOUR CLIENT CERTIFICATE PATH>'

def logRequest(test_info, url, request_body)
  puts test_info
  puts "URL : #{url}"
  if (request_body != nil && request_body != '')
    puts "Request Body : "
    puts request_body
  end
end

def logResponse(response)
  puts "Response Status : #{response.code.to_s}"
  puts "Response Headers : "
  for header, value in response.headers
    puts "#{header.to_s} : #{value.to_s}"
  end
  puts "Response Body : " + JSON.pretty_generate(JSON.parse(response.body))
end

def doMutualAuthRequest(path, test_info, method_type, request_body, headers = {})
  url = @visa_url + "#{path}"
  logRequest(test_info, url, request_body)
  if method_type == 'post' || method_type == 'put'
    headers['Content-type'] = 'application/json'
  end
  headers['accept'] = 'application/json'

  begin
    response = RestClient::Request.execute(
        :method => method_type,
        :url => url,
        :headers => headers,
        :payload => request_body,
        :user => @user_id,
        :password => @password,
        :ssl_client_key => OpenSSL::PKey::RSA.new(File.read(@key_path)),
        :ssl_client_cert => OpenSSL::X509::Certificate.new(File.read(@cert_path))
    )
    logResponse(response)
    return response.code.to_s
  rescue RestClient::ExceptionWithResponse => e
    logResponse(e.response)
    return e.response.code.to_s
  end
end

base_uri = 'vdp/'
resource_path = 'helloworld'
response_code = doMutualAuthRequest("#{base_uri}#{resource_path}", "", "get", "")
fail 'Hello world test failed' if "200" != response_code
